//
//  MemberDetailsVC.swift
//  EntrepreneurBooks
//
//  Created by VSL057 on 18/07/19.
//  Copyright © 2019 VamshiKrishna. All rights reserved.
//

import UIKit
import CoreData

class MemberDetailsVC: UIViewController,ChoosePicture {
    
    // MARK: - IBOutlets
    // MARK: -
    @IBOutlet weak var imgMemberProfile: UIImageView!
    @IBOutlet weak var txtMemberName: UITextField!
    @IBOutlet weak var txtMemberEmail: UITextField!
    @IBOutlet weak var txtMemberCellPhnNo: UITextField!
    @IBOutlet weak var bntSaveUpdate: UIButton!
    
    var isCellEdit = Bool()
    var idEdit = Int()
    var coreData = CoreDataStack()
    
    // MARK: - View LifeCycle
    // MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = .MemberDetails
        imgMemberProfile.addTapGestureRecognizer {
            self.takeAndChoosePhoto1()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if isCellEdit {
            bntSaveUpdate.setTitle("UPDATE", for: .normal)
            let managedContext = coreData.persistentContainer.viewContext
            
            // 2
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Members")
            do {
                let test = try managedContext.fetch(fetchRequest)
                let objectUpdate = test[idEdit] as! NSManagedObject
                txtMemberName.text = objectUpdate.value(forKey: "memberName") as? String
                txtMemberEmail.text = objectUpdate.value(forKey: "memberEmail") as? String
                txtMemberCellPhnNo.text = objectUpdate.value(forKey: "memberCellNo") as? String
                if let decodedImageData = Data(base64Encoded: objectUpdate.value(forKey: "memberImage") as! String, options: .ignoreUnknownCharacters) {
                    let image = UIImage(data: decodedImageData)
                    imgMemberProfile.image = image
                }
            }catch{
                print(error)
            }
        }else{
            bntSaveUpdate.setTitle("SAVE", for: .normal)
        }
    }
    
    // MARK: - UIButton Actions
    // MARK: -
    @IBAction func btnSaveAction(_ sender: Any) {
       
        // Hide keyboard
        if txtMemberName.isFirstResponder || txtMemberEmail.isFirstResponder || txtMemberCellPhnNo.isFirstResponder {
            view.endEditing(true)
        }
        // Validations
        if txtMemberName.text!.isEmpty || txtMemberEmail.text!.isEmpty || txtMemberCellPhnNo.text!.isEmpty || imgMemberProfile.image == nil{
            let alert = UIAlertController(title: "coreData", message: "Please add all field first", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true, completion: nil)
        }else{
            
            //convert image to base64
            let imageData:NSData = imgMemberProfile.image!.pngData()! as NSData
            let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
            
            if isCellEdit {
                let managedContext = coreData.persistentContainer.viewContext
                let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "Members")
                do
                {
                    let test = try managedContext.fetch(fetchRequest)
                    let objectUpdate = test[idEdit] as! NSManagedObject
                    objectUpdate.setValue(txtMemberName.text!, forKeyPath: "memberName")
                    objectUpdate.setValue(txtMemberCellPhnNo.text!, forKeyPath: "memberCellNo")
                    objectUpdate.setValue(txtMemberEmail.text!, forKeyPath: "memberEmail")
                    objectUpdate.setValue(strBase64, forKeyPath: "memberImage")
                    do{
                        try managedContext.save()
                        self.navigationController?.popViewController()
                    }
                    catch
                    {
                        print(error)
                    }
                }
                catch
                {
                    print(error)
                }
            }else{
                
                // 1
                let managedContext = coreData.persistentContainer.viewContext
                
                // 2
                let entity =
                    NSEntityDescription.entity(forEntityName: "Members",
                                               in: managedContext)!
                
                let member = NSManagedObject(entity: entity,
                                             insertInto: managedContext)
                
                // 3
                member.setValue(txtMemberName.text!, forKeyPath: "memberName")
                member.setValue(txtMemberCellPhnNo.text!, forKeyPath: "memberCellNo")
                member.setValue(txtMemberEmail.text!, forKeyPath: "memberEmail")
                member.setValue(strBase64, forKeyPath: "memberImage")
                
                // 4
                do {
                    try managedContext.save()
                    //people.append(member)
                    self.navigationController?.popViewController()
                } catch let error as NSError {
                    print("Could not save. \(error), \(error.userInfo)")
                }
            }
        }
    }
}

extension MemberDetailsVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imgMemberProfile.image = UIImage()
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)
        if let pickedImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.editedImage)] as? UIImage {
            DispatchQueue.main.async {
                self.imgMemberProfile.image = pickedImage
                self.imgMemberProfile.setNeedsDisplay()
            }
        }
        else if let pickedImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage
        {
            DispatchQueue.main.async {
                self.imgMemberProfile.image = pickedImage
                self.imgMemberProfile.setNeedsDisplay()
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }
    
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
        return input.rawValue
    }
}
