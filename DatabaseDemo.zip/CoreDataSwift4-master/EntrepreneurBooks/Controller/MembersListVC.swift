//
//  MembersListVC.swift
//  EntrepreneurBooks
//
//  Created by VSL057 on 18/07/19.
//  Copyright © 2019 VamshiKrishna. All rights reserved.
//

import UIKit
import CoreData

class MembersListVC: UIViewController,NSFetchedResultsControllerDelegate{

    // MARK: - IBOutlets
    // MARK: -
    @IBOutlet weak var tblMemberList: UITableView!
    
    var fetchedResultsController : NSFetchedResultsController<Members>!
    var bookToDelete:Members?
    var coreData = CoreDataStack()

    // MARK: - View LifeCycle
    // MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMemberList.estimatedRowHeight = UITableView.automaticDimension
        tblMemberList.rowHeight = 120
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadData()
        fetchedResultsController.managedObjectContext.refreshAllObjects()
        tblMemberList.reloadData()
    }
    
    // MARK: - UIButton Actions
    // MARK: -
    @IBAction func btnAddNewMemberAction(_ sender: Any) {
        let nextVC = viewController(withID:"MemberDetailsVC")
        self.navigationController?.pushViewController(nextVC, animated: true)
    }

    private func loadData(){
        fetchedResultsController = BookService.getBooks(managedObjectContext: coreData.persistentContainer.viewContext)
        fetchedResultsController.delegate = self
    }
}

extension MembersListVC : UITableViewDelegate,UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        if let sections = fetchedResultsController.sections{
            return sections.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let sections = fetchedResultsController.sections{
            let currentSection = sections[section]
            return currentSection.numberOfObjects
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    // Set the spacing between sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    
    // Make the background color show through
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMemberList.dequeueReusableCell(withIdentifier: "MemberTblCell") as! MemberTableViewCell
        let members = fetchedResultsController.object(at: indexPath)
        cell.lblMemberName.text = members.memberName
        cell.lblMemberEmail.text = members.memberEmail
        cell.lblMemberCellPhnNo.text = String(members.memberCellNo!)
       
        //decode back to uiimage
        if let decodedImageData = Data(base64Encoded: members.memberImage!, options: .ignoreUnknownCharacters) {
            let image = UIImage(data: decodedImageData)
            cell.imgMemberProfile.image = image
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {


        let editAction = UITableViewRowAction(style: .normal, title: "Edit") { (rowAction, indexPath) in
            //TODO: edit the row at indexPath here
            let nextVC = viewController(withID:"MemberDetailsVC") as! MemberDetailsVC
            nextVC.isCellEdit = true
            nextVC.idEdit = indexPath.row
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        editAction.backgroundColor = .blue
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            //TODO: Delete the row at indexPath here
            
            let alertController = UIAlertController(title: "Member List", message: "Are you sure you want to delete \(String(describing: self.bookToDelete?.memberName)) from your List?", preferredStyle: UIAlertController.Style.actionSheet)
            let deleteAction = UIAlertAction(title: "Delete", style: UIAlertAction.Style.default, handler: { [weak self](action:UIAlertAction) in
                
                //We need to create a context from this container
                let managedContext = self!.coreData.persistentContainer.viewContext
                
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Members")
                do
                {
                    let test = try managedContext.fetch(fetchRequest)
                    let objectToDelete = test[indexPath.row] as! NSManagedObject
                    managedContext.delete(objectToDelete)
                    
                    do{
                        try managedContext.save()
                        self!.tblMemberList.reloadData()
                    }
                    catch
                    {
                        print(error)
                    }
                    
                }
                catch
                {
                    print(error)
                }
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: {[weak self] (action:UIAlertAction) in
                self?.dismiss(animated: true, completion: nil)
            })
            alertController.addAction(deleteAction)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
            }
        deleteAction.backgroundColor = .red
        return [editAction,deleteAction]
    }
}
