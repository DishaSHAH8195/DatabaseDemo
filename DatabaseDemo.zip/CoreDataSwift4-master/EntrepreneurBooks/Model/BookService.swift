//
//  BookService.swift
//  EntrepreneurBooks
//
//  Created by Priyanka Pote on 06/11/17.
//  Copyright © 2017 VamshiKrishna. All rights reserved.
//

import Foundation
import CoreData

class BookService {
    
    internal static func getBooks(managedObjectContext:NSManagedObjectContext) -> NSFetchedResultsController<Members> {
        let fetchedResultController: NSFetchedResultsController<Members>
        
        let request: NSFetchRequest<Members> = Members.fetchRequest()
        let sort = NSSortDescriptor(key: "memberName", ascending: true)
        request.sortDescriptors = [sort]
        
        fetchedResultController = NSFetchedResultsController(fetchRequest: request, managedObjectContext: managedObjectContext, sectionNameKeyPath: nil, cacheName: nil)
        
        do {
            try fetchedResultController.performFetch()
        }
        catch {
            fatalError("Error in fetching records")
        }
        
        return fetchedResultController
    }
}
