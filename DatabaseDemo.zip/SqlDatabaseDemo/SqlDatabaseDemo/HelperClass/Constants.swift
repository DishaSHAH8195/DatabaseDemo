//
//  Utility.swift

import UIKit
import Foundation

extension UIColor {
    class func appNavigationColor() -> UIColor { return UIColor(red: 242.0/255.0, green: 242.0/255.0, blue: 242.0/255.0 , alpha: 1.0) }
    class func appNavigationTitleColor() -> UIColor { return UIColor(red: 76.0/255.0, green: 76.0/255.0, blue: 76.0/255.0 , alpha: 1.0) }
    class func appNavigationGreenColor() -> UIColor { return UIColor(red: 60.0/255.0, green: 158.0/255.0, blue: 55.0/255.0 , alpha: 1.0) }
    class func appNavigationTintColor() -> UIColor { return UIColor(red: 166.0/255.0, green: 168.0/255.0, blue: 171.0/255.0 , alpha: 1.0) }
    class func lightBorderColor() -> UIColor { return UIColor(red: 204, green: 204, blue: 204 ,alpha: 1) }
    class func lightGrayStepColor() -> UIColor { return UIColor(red: 204.0/255.0, green: 204.0/255.0, blue: 204.0/255.0 ,alpha:1) }
    //MessageVC Used Colors
    class func msgInputBarBorderColor() -> UIColor { return UIColor(red: 208/255, green: 208/255, blue: 208/255, alpha: 1) }
    class func msgInputBarBackColor() -> UIColor { return UIColor(red: 238/255, green: 238/255, blue: 238/255, alpha: 1) }
    class func msgTopViewLblHeadingColor() -> UIColor { return UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1) }
    class func msgTopViewLblDetailColor() -> UIColor { return UIColor(red: 152/255, green: 152/255, blue: 152/255, alpha: 1) }
    class func msgTopLblDateTimeColor() -> UIColor { return UIColor(red: 153/255, green: 153/255, blue: 153/255, alpha: 1) }
    class func msgLblReceiverColor() -> UIColor { return UIColor(red: 102/255, green: 102/255, blue: 102/255, alpha: 1) }
    class func msgLblSenderBackColor() -> UIColor { return UIColor(red: 230/255, green: 255/255, blue: 230/255, alpha: 1) }
    class func msgLblReceiverBackColor() -> UIColor { return UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1) }
    class func msgLblSenderBorderColor() -> UIColor { return UIColor(red: 61/255, green: 161/255, blue: 57/255, alpha: 1) }
    class func msgLblReceiverBorderColor() -> UIColor { return UIColor(red: 153/255, green: 153/255, blue: 153/255, alpha: 1) }

    class func blackColor() -> UIColor { return UIColor.black }
    class func whiteColor() -> UIColor { return UIColor.white }
    class func lightGrayColor() -> UIColor { return UIColor.lightGray }
    class func grayColor() -> UIColor { return UIColor.gray }
    class func darkGrayColor() -> UIColor { return UIColor.darkGray }
    class func redColor() -> UIColor { return UIColor.red }
    class func clearColor() -> UIColor { return UIColor.clear }
    
    //For Switch
    class func switchBackOnOffTintColor() -> UIColor { return UIColor(red: 227.0/255.0, green: 225.0/255.0, blue: 226.0/255.0 ,alpha:1) }
    
    class func switchOffThumbTintColor() -> UIColor { return UIColor(red: 181.0/255.0, green: 181.0/255.0, blue: 181.0/255.0 ,alpha:1) }
}

extension String {
    // MARK: - Font Name
    static let fontGothamBook            = "Gotham-Book"
    static let fontGothamBold            = "Gotham-Bold"
    static let fontOpenSansBold          = "OpenSans-Bold"
    static let fontOpenSansSemibold      = "OpenSans-Semibold"
    static let fontLatoBold              = "Lato-Bold"
    
    // MARK: - StoryBoard Identifier's
    static let sIdSlideMenuVC            = "SlideMenuVC"

    // cell Identifier's
    static let sIdSlideMenuCell          = "SlideMenuCell"
    
    // MARK: - Message's
    static let msgNetworkConnection = "You Are Not Connected To Internet. Please Connect And Try Again"
    static let msgLocationNotFound = "Unable To Fetch Current Location"

    // MARK: - Navigation titles
    static let MemberList = "Member List"
    static let MemberDetails = "Member Details"
    
    // MARK: - Navigation class
    static let MemberListVC = "MemberListVC"
    static let SaveUpdateMemberVC = "SaveUpdateMemberVC"

}

extension UIButton {
    
    class func menuButtonTarget(_ target: Any, action: Selector) -> UIBarButtonItem {
        let menuButton = UIButton(frame: CGRect(x: CGFloat(0), y: CGFloat(0), width: CGFloat(12), height: CGFloat(20)))
        menuButton.setBackgroundImage(UIImage(named:"menu_Icon"), for: .normal)
        let barMenuButtonItem = UIBarButtonItem(customView: menuButton)
        menuButton.addTarget(target, action: action, for: .touchUpInside)
        return barMenuButtonItem
    }
}

struct Constants {
    // MARK: - Global Utility
    static let appName    = Bundle.main.infoDictionary!["CFBundleName"] as! String
    static let mainStoryboard = UIStoryboard(name: "Main", bundle: nil)
    static let appDelegate = UIApplication.shared.delegate as! AppDelegate
    static let mainWindow = UIApplication.shared.delegate?.window!
    static let rootView = UIApplication.shared.keyWindow
    static let deviceID = UIDevice.current.identifierForVendor?.uuidString

    //MARK: - device type
    enum UIUserInterfaceIdiom : Int{
        case Unspecified
        case Phone
        case Pad
    }
    
    public enum validationMessages:String {
        case emptyCellNo = "Please Enter CellPhone Number"
        case emptyEmail = "Please Enter Email Address"
        case emptyName = "Please Enter Name"
        case emptyProfImg = "Please Select Profile Image"
        case onAddSuccess = "Member Data Added Successfully"
        case onUpdateSuccess = "Member Data Updated Added Successfully"
        case errorMsg = "Problem Adding/Updating Member Data"
    }
    
   public enum imageAssetsName:String {
        case menuIcon = "menu"
    }

    struct ScreenSize {
        static let SCREEN_WIDTH         = UIScreen.main.bounds.size.width
        static let SCREEN_HEIGHT        = UIScreen.main.bounds.size.height
        static let SCREEN_MAX_LENGTH    = max(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
        static let SCREEN_MIN_LENGTH    = min(ScreenSize.SCREEN_WIDTH, ScreenSize.SCREEN_HEIGHT)
    }
    
    struct DeviceType
    {
        static let IS_IPHONE_4_OR_LESS  = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH < 568.0
        static let IS_IPHONE_5          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 568.0
        static let IS_IPHONE_6          = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 667.0
        static let IS_IPHONE_6P         = UIDevice.current.userInterfaceIdiom == .phone && ScreenSize.SCREEN_MAX_LENGTH == 736.0
        static let IS_IPAD              = UIDevice.current.userInterfaceIdiom == .pad && ScreenSize.SCREEN_MAX_LENGTH == 1024.0
    }
    
    struct DateFormat
    {
        static let date = "dd/MM/yy"
        static let time = "hh:mm a"
    }
    
    struct WebServiceURLs {
        static let api_key = ""
       
        static let mainURL = ""

        static let saveDriver = mainURL + "/"
    }
}
