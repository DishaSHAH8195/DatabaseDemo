//
//  Members.swift
//  SqlDatabaseDemo
//
//  Created by VSL057 on 16/07/19.
//  Copyright © 2019 VSL057. All rights reserved.
//

import UIKit

class Members: SQLTable {
    var id = -1
    var memberImage = ""
    var memberName = ""
    var memberEmail = ""
    var memberCellNo = 0
}
