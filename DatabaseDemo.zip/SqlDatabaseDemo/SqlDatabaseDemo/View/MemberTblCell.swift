//
//  MemberTblCell.swift
//  SqlDatabaseDemo
//
//  Created by VSL057 on 16/07/19.
//  Copyright © 2019 VSL057. All rights reserved.
//

import UIKit

class MemberTblCell: UITableViewCell {

    @IBOutlet weak var imgMemberProfile: UIImageView!
    @IBOutlet weak var lblMemberName: UILabel!
    @IBOutlet weak var lblMemberEmail: UILabel!
    @IBOutlet weak var lblMemberCellPhnNo: UILabel!
    
    // MARK: - Cell Methods
    // MARK: -
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
