//
//  ViewController.swift
//  SqlDatabaseDemo
//
//  Created by VSL057 on 16/07/19.
//  Copyright © 2019 VSL057. All rights reserved.
//

import UIKit

class MemberListVC: UIViewController{
    
    // MARK: - IBOutlets
    // MARK: -
    @IBOutlet weak var tblMemberList: UITableView!
    
    var members = [Members]()

    // MARK: - View LifeCycle
    // MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        tblMemberList.estimatedRowHeight = UITableView.automaticDimension
        tblMemberList.rowHeight = 120
    }
    
    override func viewWillAppear(_ animated:Bool) {
        super.viewWillAppear(animated)
        members = Members.rows(order:"memberName ASC")
        tblMemberList.reloadData()
    }

    // MARK: - UIButton Actions
    // MARK: -
    @IBAction func btnAddNewMemberAction(_ sender: Any) {
        let vc = viewController(withID:.SaveUpdateMemberVC)
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension MemberListVC : UITableViewDelegate,UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return members.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    // Set the spacing between sections
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10.0
    }
    
    // Make the background color show through
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblMemberList.dequeueReusableCell(withIdentifier: String(describing:MemberTblCell.self)) as! MemberTblCell
        cell.lblMemberName.text = members[indexPath.section].memberName
        cell.lblMemberEmail.text = members[indexPath.section].memberEmail
        cell.lblMemberCellPhnNo.text = String(members[indexPath.section].memberCellNo)
        //decode back to uiimage
        if let decodedImageData = Data(base64Encoded: members[indexPath.section].memberImage, options: .ignoreUnknownCharacters) {
            let image = UIImage(data: decodedImageData)
            cell.imgMemberProfile.image = image
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let members = self.members[indexPath.section]
        let id = members.id
        
        let editAction = UITableViewRowAction(style: .normal, title: "Edit") { (rowAction, indexPath) in
            //TODO: edit the row at indexPath here
            let nextVC = viewController(withID:.SaveUpdateMemberVC) as! SaveUpdateMemberVC
            nextVC.isCellEdit = true
            nextVC.idEdit = id
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        editAction.backgroundColor = .blue
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            //TODO: Delete the row at indexPath here
            if let members = Members.rowBy(id: id) {
                _ = members.delete()
                self.viewWillAppear(true)
                NSLog("Deleted Member with ID = \(id)")
            }
        }
        deleteAction.backgroundColor = .red
        return [editAction,deleteAction]
    }
}
