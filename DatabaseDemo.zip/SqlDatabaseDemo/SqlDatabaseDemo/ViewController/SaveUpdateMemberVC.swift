//
//  SaveUpdateMemberVC.swift
//  SqlDatabaseDemo
//
//  Created by VSL057 on 16/07/19.
//  Copyright © 2019 VSL057. All rights reserved.
//

import UIKit

class SaveUpdateMemberVC: UIViewController,ChoosePicture{
    
    // MARK: - IBOutlets
    // MARK: -
    @IBOutlet weak var imgMemberProfile: UIImageView!
    @IBOutlet weak var txtMemberName: UITextField!
    @IBOutlet weak var txtMemberEmail: UITextField!
    @IBOutlet weak var txtMemberCellPhnNo: UITextField!
    @IBOutlet weak var bntSaveUpdate: UIButton!
    
    var isCellEdit = Bool()
    var idEdit = Int()

    // MARK: - View LifeCycle
    // MARK: -
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = .MemberDetails
        imgMemberProfile.addTapGestureRecognizer {
            self.takeAndChoosePhoto1()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if isCellEdit {
            bntSaveUpdate.setTitle("UPDATE", for: .normal)
            if let members = Members.rowBy(id: idEdit) {
                txtMemberName.text = members.memberName
                txtMemberEmail.text = members.memberEmail
                txtMemberCellPhnNo.text = String(members.memberCellNo)
                if let decodedImageData = Data(base64Encoded: members.memberImage, options: .ignoreUnknownCharacters) {
                    let image = UIImage(data: decodedImageData)
                    imgMemberProfile.image = image
                }
            }
        }else{
            bntSaveUpdate.setTitle("SAVE", for: .normal)
        }
    }
    
    @IBAction func btnSaveAction(_ sender: Any) {
        // Hide keyboard
        if txtMemberName.isFirstResponder || txtMemberEmail.isFirstResponder || txtMemberCellPhnNo.isFirstResponder {
            view.endEditing(true)
        }
        // Validations
        if txtMemberName.text!.isEmpty || txtMemberEmail.text!.isEmpty || txtMemberCellPhnNo.text!.isEmpty || imgMemberProfile.image == nil{
            let alert = UIAlertController(title: "SQLiteDB", message: "Please add all field first", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true, completion: nil)
        }else{
            
            if isCellEdit {
                if let members = Members.rowBy(id: idEdit) {
                  members.memberName = txtMemberName.text!
                   members.memberEmail = txtMemberEmail.text!
                    members.memberCellNo = Int(txtMemberCellPhnNo.text!)!
                    
                    //convert image to base64
                    let imageData:NSData = imgMemberProfile.image!.pngData()! as NSData
                    let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
                    members.memberImage = strBase64

                    if members.save() != 0 {
                        let alert = UIAlertController(title: "SQLiteDB", message: "Member successfully Updated!", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                            self.navigationController?.popViewController()
                        }))
                        present(alert, animated: true, completion: nil)
                    }
                }
            }
            else{
            let members = Members()
            members.memberName = txtMemberName.text!
            members.memberEmail = txtMemberEmail.text!
            members.memberCellNo = Int(txtMemberCellPhnNo.text!)!
            
            //convert image to base64
            let imageData:NSData = imgMemberProfile.image!.pngData()! as NSData
            let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
            members.memberImage = strBase64
            
            if members.save() != 0 {
                let alert = UIAlertController(title: "SQLiteDB", message: "Member successfully saved!", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction.init(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                    self.navigationController?.popViewController()
                }))
                present(alert, animated: true, completion: nil)
                }
            }
        }
    }
}

extension SaveUpdateMemberVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imgMemberProfile.image = UIImage()
        let info = convertFromUIImagePickerControllerInfoKeyDictionary(info)
        if let pickedImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.editedImage)] as? UIImage {
            DispatchQueue.main.async {
                self.imgMemberProfile.image = pickedImage
                self.imgMemberProfile.setNeedsDisplay()
            }
        }
        else if let pickedImage = info[convertFromUIImagePickerControllerInfoKey(UIImagePickerController.InfoKey.originalImage)] as? UIImage
        {
            DispatchQueue.main.async {
                self.imgMemberProfile.image = pickedImage
                self.imgMemberProfile.setNeedsDisplay()
            }
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKeyDictionary(_ input: [UIImagePickerController.InfoKey: Any]) -> [String: Any] {
        return Dictionary(uniqueKeysWithValues: input.map {key, value in (key.rawValue, value)})
    }
    
    // Helper function inserted by Swift 4.2 migrator.
    fileprivate func convertFromUIImagePickerControllerInfoKey(_ input: UIImagePickerController.InfoKey) -> String {
        return input.rawValue
    }
}
